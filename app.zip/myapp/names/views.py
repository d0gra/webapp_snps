from django.shortcuts import render
from django.db.models import Q

# Create your views here.
from django.views.generic import TemplateView, ListView

from .models import names


class HomePageView(TemplateView):
    template_name = 'home.html'



class SearchResultsView(ListView):
    model = names
    template_name = 'search_results.html'
    
   

    def get_queryset(self): # new
        query = self.request.GET.get('q')
        object_list = names.objects.filter(
            Q(name__icontains=query) | Q(company__icontains=query)
        )
        return object_list

