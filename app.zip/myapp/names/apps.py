from django.apps import AppConfig


class NamesConfig(AppConfig):
    name = 'names'
