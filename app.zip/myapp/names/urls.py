from django.urls import path

from .views import HomePageView, SearchResultsView

urlpatterns = [
    path('search/', SearchResultsView.as_view(template_name='search_results.html'), name='search_results'),
    path('', HomePageView.as_view(), name='home'),
]
