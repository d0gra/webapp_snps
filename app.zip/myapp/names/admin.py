
# Register your models here.
from django.contrib import admin

from .models import names
class namesAdmin(admin.ModelAdmin):
    list_display = ("name", "company",)

admin.site.register(names, namesAdmin)

